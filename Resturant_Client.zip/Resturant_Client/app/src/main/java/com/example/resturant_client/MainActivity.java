package com.example.resturant_client;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;

import java.util.ArrayList;
import java.util.List;

import OrderPizza.MethodOrder;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    TextView txtResult;
    Button btnOrder;
    EditText edtNumber,edtname;
    private MethodOrder methodOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageSlider imageSlider=findViewById(R.id.image_slider);
        List<SlideModel> imageList=new ArrayList<>();
        imageList.add(new SlideModel(R.drawable.corn_pizza,"Corn Pizza" , ScaleTypes.FIT));
        imageList.add(new SlideModel(R.drawable.pepperoni, "Pepperoni Pizza",ScaleTypes.FIT));
        imageList.add(new SlideModel(R.drawable.veg,"Veg Pizza", ScaleTypes.FIT));
        imageSlider.setImageList(imageList,ScaleTypes.FIT);
        edtname=(EditText)findViewById(R.id.edtName);
        edtNumber=(EditText)findViewById(R.id.edtNumber);
        txtResult=(TextView)findViewById(R.id.txtResult);
        btnOrder=(Button)findViewById(R.id.btnOrder);
        btnOrder.setOnClickListener(MainActivity.this);
        bindToService();

    }
    private void bindToService() {
        Intent aidlintent=new Intent("connect_to_product");
        bindService(implicitIntentToExplicitIntent(aidlintent,this),serviceConnection,BIND_AUTO_CREATE);
    }
    ServiceConnection serviceConnection=new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            methodOrder=MethodOrder.Stub.asInterface(service);

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };

    public static Intent implicitIntentToExplicitIntent(Intent implicitIntent, Context context) {
        PackageManager pm = context.getPackageManager();
        List<ResolveInfo> resolveInfoList = pm.queryIntentServices(implicitIntent, 0);

        if (resolveInfoList == null || resolveInfoList.size() != 1) {
            return null;
        }
        ResolveInfo serviceInfo = resolveInfoList.get(0);
        ComponentName component = new ComponentName(serviceInfo.serviceInfo.packageName, serviceInfo.serviceInfo.name);
        Intent explicitIntent = new Intent(implicitIntent);
        explicitIntent.setComponent(component);
        return explicitIntent;
    }

    @Override
    public void onClick(View v) {
        String strN=edtname.getText().toString();
        int Num=Integer.parseInt(edtNumber.getText().toString());
        String result= null;
        try {
            result = methodOrder.disData(strN,Num);
            txtResult.setText(result);
        } catch (RemoteException e) {
            e.printStackTrace();
        }


    }

}