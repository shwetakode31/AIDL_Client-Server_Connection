package com.example.resturant_server;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import OrderPizza.MethodOrder;

public class MyService extends Service {
    public MyService() {
    }


    @Override
    public IBinder onBind(Intent intent) {
        return aildObj;
    }
    MethodOrder.Stub aildObj=new MethodOrder.Stub() {
        @Override
        public String disData(String name, int quantiy) throws RemoteException {
            return displayData(name,quantiy);
        }
    };
    public String displayData(String name,int quantiy) {

        String data=null;
        int newP=quantiy*90;
        data = "**** ORDER DETAILS ****"+ "\n"+"Customer Name : " + name +"\n"+"Price " +
                ": Rs.90 (per pizza) " + "\n"+"Quantity : " + quantiy +"\t\t"+ "\n"+"Total Bill Amount : " + newP +"\n................................\nThank You for choosing pizza \nHave A Nice Day ";
        Log.d("Service_Result",""+String.valueOf(data));
        return data;
    }
}